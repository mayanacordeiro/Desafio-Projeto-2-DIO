import UIKit

enum CompassPoint {
    case north
    case south
    case east
    case west
}

let direction = CompassPoint.north

switch direction {
case .north:
    print("Heading North")
case .south:
    print("Heading South")
case .east:
    print("Heading East")
case .west:
    print("Heading West")
}


struct Person {
    var name: String
    var age: Int
}

var person = Person(name: "John Doe", age: 30)
person.age = 31

print("\(person.name) is \(person.age) years old.")


let score = 85

if score >= 90 {
    print("A")
} else if score >= 80 {
    print("B")
} else if score >= 70 {
    print("C")
} else {
    print("F")
}


var shoppingList = ["Apples", "Bananas", "Oranges"]
shoppingList.append("Milk")
shoppingList.remove(at: 1)

for item in shoppingList {
    print(item)
}


func greet(name: String) -> String {
    return "Hello, \(name)!"
}

let greeting = greet(name: "Jane")
print(greeting)


class OnePerson {
    var name: String
    var age: Int
    
    init(name: String, age: Int) {
        self.name = name
        self.age = age
    }
    
    func sayHello() {
        print("Hello, my name is \(name).")
    }
}

let onePerson = OnePerson(name: "Alice", age: 25)
onePerson.sayHello()


