import UIKit

protocol Vehicle {
    var numberOfWheels: Int { get }
    func startEngine()
}

struct Car: Vehicle {
    var numberOfWheels = 4
    
    func startEngine() {
        print("Starting car engine")
    }
}

struct Motorcycle: Vehicle {
    var numberOfWheels = 2
    
    func startEngine() {
        print("Starting motorcycle engine")
    }
}

let myCar = Car()
myCar.startEngine()

let myMotorcycle = Motorcycle()
myMotorcycle.startEngine()


protocol Shape {
    var area: Double { get }
}

struct Rectangle: Shape {
    var length: Double
    var width: Double
    
    var area: Double {
        return length * width
    }
}

struct Circle: Shape {
    var radius: Double
    
    var area: Double {
        return Double.pi * radius * radius
    }
}

let rectangle = Rectangle(length: 5, width: 3)
let circle = Circle(radius: 4)

print("Area of rectangle: \(rectangle.area)")
print("Area of circle: \(circle.area)")


protocol CanDrive {
    var hasDriverLicense: Bool { get set }
    func drive()
}

class Person: CanDrive {
    var hasDriverLicense: Bool = false
    
    func drive() {
        if hasDriverLicense {
            print("Driving...")
        } else {
            print("Cannot drive without a driver's license.")
        }
    }
}

let john = Person()
john.drive() // Saída: Cannot drive without a driver's license.

john.hasDriverLicense = true
john.drive() // Saída: Driving...


protocol GroceryItem {
    var name: String { get }
    var category: String { get }
}

struct Fruit: GroceryItem {
    var name: String
    var category: String = "Fruit"
}

struct Vegetable: GroceryItem {
    var name: String
    var category: String = "Vegetable"
}

let apple = Fruit(name: "Apple")
let banana = Fruit(name: "Banana")
let carrot = Vegetable(name: "Carrot")

let groceryList: [GroceryItem] = [apple, banana, carrot]

for item in groceryList {
    print("\(item.name) - \(item.category)")
}

